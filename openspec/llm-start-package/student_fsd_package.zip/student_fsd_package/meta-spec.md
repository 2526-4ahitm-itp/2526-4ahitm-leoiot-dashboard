# Meta-Spezifikation für Schüler

## Zweck
Diese Meta-Spezifikation hilft dabei, einen **Vorbereitungstext** für ein Software- oder Digitalprojekt zu verfassen. Dieser Vorbereitungstext soll so klar und vollständig sein, dass daraus anschließend mit einer KI ein **Functional Specification Document (FSD)** in englischer Sprache erstellt werden kann.

Die Schüler verfassen also **nicht sofort** die technische Spezifikation, sondern zuerst einen gut strukturierten deutschsprachigen Beschreibungstext.

---

## Ziel des Vorbereitungstextes
Der Vorbereitungstext soll alle Informationen enthalten, die notwendig sind, damit eine KI:

1. das Projekt richtig versteht,
2. die Aufgabenstellung präzise erfassen kann,
3. den Funktionsumfang erkennt,
4. Grenzen und Nicht-Ziele beachtet,
5. daraus ein vollständiges **Functional Specification Document** erstellen kann.

---

## Allgemeine Schreibregeln

### Der Text soll
- sachlich formuliert sein,
- klar gegliedert sein,
- in ganzen Sätzen geschrieben sein,
- für Außenstehende verständlich sein,
- konkrete Anforderungen enthalten,
- Unsicherheiten offen benennen.

### Der Text soll nicht
- nur aus Stichwörtern bestehen,
- unklare Werbesprache verwenden,
- wichtige Begriffe undefiniert lassen,
- Problem, Ziel und Lösung vermischen,
- Funktionen beschreiben, die eigentlich gar nicht zum Projekt gehören.

---

## Qualitätskriterien
Ein guter Vorbereitungstext ist:

- **klar**: Man versteht sofort, worum es geht.
- **konkret**: Anforderungen sind nicht nur allgemein formuliert.
- **vollständig genug**: Die wichtigsten Informationen fehlen nicht.
- **widerspruchsfrei**: Aussagen passen zusammen.
- **abgegrenzt**: Es ist klar, was zum Projekt gehört und was nicht.
- **brauchbar für KI-Weiterverarbeitung**: Eine KI kann daraus eine Spezifikation ableiten.

---

## Aufbau des Vorbereitungstextes

Die Schüler sollen ihren Text nach den folgenden Abschnitten gliedern.

### 1. Projekttitel
Beschreibe den Arbeitstitel oder den geplanten Namen des Projekts.

**Leitfragen:**
- Wie heißt das Projekt?
- Gibt es einen kurzen, verständlichen Titel?

---

### 2. Kurzbeschreibung
Beschreibe das Projekt in **3 bis 6 Sätzen**.

**Leitfragen:**
- Worum geht es insgesamt?
- Was soll am Ende entstehen?
- Wofür ist das Projekt gedacht?

---

### 3. Ausgangssituation / Ist-Zustand
Beschreibe die aktuelle Situation.

**Leitfragen:**
- Wie läuft es derzeit?
- Was funktioniert schlecht oder umständlich?
- Wer ist davon betroffen?
- Warum ist die aktuelle Situation unbefriedigend?

---

### 4. Problemstellung
Formuliere das eigentliche Problem möglichst klar.

**Leitfragen:**
- Welches Hauptproblem soll gelöst werden?
- Gibt es Teilprobleme?
- Welche Nachteile entstehen ohne Lösung?

---

### 5. Projektziel / Soll-Zustand
Beschreibe, was durch das Projekt verbessert werden soll.

**Leitfragen:**
- Was soll die Lösung können?
- Was soll danach besser sein?
- Woran erkennt man die Verbesserung?

---

### 6. Zielgruppe / Benutzergruppen
Beschreibe, wer das Produkt verwenden soll.

**Leitfragen:**
- Wer sind die Hauptnutzer?
- Gibt es verschiedene Benutzergruppen?
- Wer ist die wichtigste Zielgruppe?

---

### 7. Nutzungsszenarien
Beschreibe typische Situationen, in denen das Produkt verwendet wird.

**Leitfragen:**
- Wann wird das Produkt benutzt?
- Was möchte der Benutzer konkret tun?
- Wie läuft eine typische Nutzung ab?

**Hinweis:**
Beschreibe **1 bis 3 typische Nutzungsszenarien**.

---

### 8. Funktionen des Systems
Liste die geplanten Funktionen möglichst konkret auf.

**Leitfragen:**
- Was muss das System können?
- Welche Eingaben sind möglich?
- Welche Ausgaben gibt es?
- Welche Aktionen kann ein Benutzer ausführen?

**Empfohlene Formulierung:**
- Das System soll ...
- Das System soll ...
- Das System soll ...

---

### 9. Priorisierung der Anforderungen
Ordne die Anforderungen in drei Gruppen:

- **MUSS**: unbedingt notwendig
- **SOLL**: wichtig, aber nicht zwingend für eine erste Version
- **KANN**: optional oder Erweiterung

**Beispiel:**
- MUSS: Benutzer können Einträge erstellen.
- SOLL: Benutzer können Einträge filtern.
- KANN: Benutzer können Daten exportieren.

---

### 10. Nicht-Ziele / Abgrenzung
Beschreibe ausdrücklich, was **nicht** Teil des Projekts ist.

**Leitfragen:**
- Welche Funktionen werden bewusst nicht umgesetzt?
- Was wäre zwar interessant, gehört aber nicht mehr zum Projekt?
- Wo endet der Projektumfang?

---

### 11. Inhalte / Daten
Beschreibe, welche Daten im Projekt vorkommen.

**Leitfragen:**
- Welche Daten werden eingegeben?
- Welche Daten werden gespeichert?
- Welche Daten werden angezeigt?
- Woher stammen die Daten?

---

### 12. Regeln / Bedingungen / Einschränkungen
Beschreibe feste Rahmenbedingungen.

**Leitfragen:**
- Gibt es technische Einschränkungen?
- Gibt es schulische oder zeitliche Grenzen?
- Muss das System auf bestimmten Geräten laufen?
- Gibt es Vorgaben zu Datenschutz, Registrierung oder Internetzugang?

---

### 13. Anforderungen an Qualität und Benutzerfreundlichkeit
Beschreibe, welche Qualitätsansprüche gelten.

**Leitfragen:**
- Soll die Bedienung besonders einfach sein?
- Soll die Oberfläche übersichtlich sein?
- Wie wichtig sind Geschwindigkeit und Fehlertoleranz?
- Welche Erwartungen gibt es an Verständlichkeit und Rückmeldungen?

---

### 14. Sonderfälle / Fehlerfälle
Beschreibe problematische oder ungewöhnliche Situationen.

**Leitfragen:**
- Was passiert bei falschen Eingaben?
- Was passiert, wenn Daten fehlen?
- Was passiert bei ungültigen Aktionen?
- Welche typischen Fehler müssen abgefangen werden?

---

### 15. Erfolgskriterien
Formuliere überprüfbare Kriterien für ein gelungenes Projekt.

**Leitfragen:**
- Woran erkennt man, dass das Projekt funktioniert?
- Welche Ergebnisse müssen am Ende vorhanden sein?
- Welche Funktionen müssen sicher nachweisbar laufen?

---

### 16. Offene Fragen / Unsicherheiten
Beschreibe alles, was noch nicht endgültig geklärt ist.

**Leitfragen:**
- Welche Entscheidungen sind noch offen?
- Wo gibt es Unsicherheiten?
- Welche Annahmen wurden bisher getroffen?

---

## Ausfüllvorlage für Schüler

# Vorbereitungstext für die Erstellung einer Functional Specification

## 1. Projekttitel
[Hier eintragen]

## 2. Kurzbeschreibung
[Hier in 3 bis 6 Sätzen beschreiben]

## 3. Ausgangssituation / Ist-Zustand
[Hier beschreiben]

## 4. Problemstellung
[Hier beschreiben]

## 5. Projektziel / Soll-Zustand
[Hier beschreiben]

## 6. Zielgruppe / Benutzergruppen
[Hier beschreiben]

## 7. Typische Nutzungsszenarien
[Hier 1 bis 3 typische Szenarien beschreiben]

## 8. Funktionen des Systems
- Das System soll ...
- Das System soll ...
- Das System soll ...

## 9. Priorisierung
### MUSS
- ...

### SOLL
- ...

### KANN
- ...

## 10. Nicht-Ziele / Abgrenzung
[Hier beschreiben]

## 11. Inhalte / Daten
[Hier beschreiben]

## 12. Regeln / Bedingungen / Einschränkungen
[Hier beschreiben]

## 13. Anforderungen an Qualität und Benutzerfreundlichkeit
[Hier beschreiben]

## 14. Sonderfälle / Fehlerfälle
[Hier beschreiben]

## 15. Erfolgskriterien
[Hier beschreiben]

## 16. Offene Fragen / Unsicherheiten
[Hier beschreiben]

---

## Merksatz für Schüler
**Frage dich beim Schreiben immer:**

> Könnte eine außenstehende Person mein Projekt auf Basis dieses Textes richtig verstehen und daraus eine brauchbare Spezifikation erstellen?
