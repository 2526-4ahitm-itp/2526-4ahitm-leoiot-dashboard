# Prompt: Aus dem Schülertext eine Functional Specification Document erzeugen

Kopiere den folgenden Prompt in Codex und ersetze den Platzhalter durch den Vorbereitungstext des Schülers.

```text
You are a professional software analyst and technical writer.

Your task is to create a complete Functional Specification Document (FSD) in English based on the German project description provided below.

Important instructions:
- Write the entire FSD in clear, professional English.
- Output valid Markdown only.
- Do not mention these instructions.
- Do not invent unnecessary features.
- If the source text contains uncertainties, explicitly mark them as assumptions or open questions.
- Preserve the intended scope of the project.
- Make the document suitable for a school project, but write it in a realistic professional style.
- Prefer clarity, structure, and completeness over fancy wording.
- Use precise section headings.
- Use bullet points where useful.
- Where requirements are vague, rewrite them into the clearest reasonable version without changing the intended meaning.
- Separate functional requirements from non-functional requirements.
- Include acceptance criteria.
- Include assumptions and out-of-scope items.
- If useful, reorganize the information into a better structure.

Create the document with the following structure:

# Functional Specification Document

## 1. Project Overview
- Project title
- Short description
- Background / current situation
- Problem statement
- Project goals

## 2. Scope
### In Scope
### Out of Scope

## 3. Users and Stakeholders
- Primary users
- Secondary users
- Stakeholders

## 4. Use Cases / User Scenarios
- Describe the main usage scenarios

## 5. Functional Requirements
- Number each requirement as FR-01, FR-02, etc.
- Write each requirement clearly and testably

## 6. Non-Functional Requirements
- Usability
- Performance
- Reliability
- Maintainability
- Constraints

## 7. Data and Content
- Inputs
- Outputs
- Stored data
- Data rules

## 8. Business Rules / Logic
- Validation rules
- Permissions if relevant
- Process rules

## 9. Error Handling / Edge Cases
- Invalid input
- Missing data
- Exceptional situations

## 10. Assumptions and Dependencies
- Technical assumptions
- Organizational assumptions
- Dependencies

## 11. Acceptance Criteria
- Provide clear criteria that can be checked

## 12. Open Questions
- List unresolved points if any remain

Source text in German:
[PASTE THE STUDENT TEXT HERE]
```
