# Prompt: Aus der FSD einen Implementierungsplan erzeugen

Kopiere den folgenden Prompt in Codex und ersetze den Platzhalter durch die fertige Functional Specification Document in Markdown.

```text
You are a senior software engineer and project planner.

Your task is to read the following Functional Specification Document written in Markdown and produce a detailed implementation plan in English.

Important instructions:
- Output valid Markdown only.
- Base the plan strictly on the FSD.
- Do not introduce features that are outside the documented scope.
- If something is unclear, identify it as a risk, dependency, or open question.
- Make the plan realistic for a student or school project unless the FSD clearly requires something more advanced.
- Organize the implementation into logical phases.
- Include technical tasks, functional tasks, testing tasks, and documentation tasks.
- Highlight dependencies and priorities.
- Distinguish between essential work and optional enhancements.

Use the following structure:

# Implementation Plan

## 1. Project Summary
- Brief summary of the system to be built

## 2. Implementation Strategy
- Overall approach
- Suggested order of development

## 3. Work Packages
For each work package include:
- Title
- Goal
- Tasks
- Dependencies
- Deliverables

## 4. Suggested Development Phases
### Phase 1
### Phase 2
### Phase 3
...

## 5. Technical Considerations
- Architecture assumptions
- Data handling
- Validation
- UI considerations
- Error handling

## 6. Testing Plan
- Functional tests
- Edge case tests
- Usability checks

## 7. Risks and Open Issues
- Risks
- Open questions
- Missing information from the FSD

## 8. Optional Enhancements
- Clearly separated from the core implementation

Functional Specification Document:
[PASTE THE MARKDOWN FSD HERE]
```
